
import java.awt.Font;
import java.awt.font.TextAttribute;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.text.AttributedString;
import java.util.logging.Level;
import java.util.logging.Logger;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author libreria6
 */
public class Edicion extends javax.swing.JFrame {
 Cancion nuevo =new Cancion();
 int n=0;
 int tamanio=0;
    /**
     * Creates new form Edicion
     */
    public Edicion(int ubicacion) {
        initComponents();
        leerRegistro(ubicacion);
        n = ubicacion;
    }
 public void leerRegistro(int ubicacion){
        try {
            RandomAccessFile almacen = new RandomAccessFile("Almacen.data","rw");
            RandomAccessFile indice = new RandomAccessFile("Indice.data","rw");
            RandomAccessFile informacion = new RandomAccessFile("Informacion.data","rw");
            RandomAccessFile letra = new RandomAccessFile("Letras.data","rw");
            almacen.seek(ubicacion);
            int posicion=ubicacion;
            int puntero;
            byte lon;
            String dato="";
            /*Pista*/
            almacen.seek(posicion);
            puntero=almacen.readShort();
            posicion+=2;
            indice.seek(puntero);
                lon=indice.readByte();
                for(int i=0; i<lon; i++){
                    dato=dato+(char)indice.readByte();
                }
                nuevo.setPista(dato);
                dato="";
                
                /*Disquera*/
                almacen.seek(posicion);
                puntero=almacen.readInt();
                posicion+=4;
                almacen.seek(puntero);
                lon=almacen.readByte();
                for(int i=0; i<lon; i++){
                    dato=dato+(char)almacen.readByte();
                }
                nuevo.setDisquera(dato);//dato actual
                this.jTextField1.setText(nuevo.getDisquera());//lo muestra en el cuadro de texto
                dato="";
                
                /*Artista*/
                almacen.seek(posicion);
                puntero=almacen.readShort();
                posicion+=2;
                indice.seek(puntero);
                lon=indice.readByte();
                for(int i=0; i<lon; i++){
                    dato=dato+(char)indice.readByte();
                }
                nuevo.setArtista(dato);
                this.jTextField2.setText(nuevo.getArtista());
                dato="";
                
                /*Album*/
                almacen.seek(posicion);
                puntero=almacen.readInt();
                posicion+=4;
                almacen.seek(puntero);
                lon=almacen.readByte();
                for(int i=0; i<lon; i++){
                    dato=dato+(char)almacen.readByte();
                }
                nuevo.setAlbum(dato);
                this.jTextField3.setText(nuevo.getAlbum());
                dato="";
                
                /*Año*/
                almacen.seek(posicion);
                puntero=almacen.readShort();
                posicion+=2;
                indice.seek(puntero);
                nuevo.setAnio(indice.readShort());
                this.jTextField4.setText(String.valueOf(nuevo.getAnio()));
                /*Genero*/
                almacen.seek(posicion);
                puntero=almacen.readInt();
                posicion+=4;
                almacen.seek(puntero);
                lon=almacen.readByte();
                for(int i=0; i<lon; i++){
                    dato=dato+(char)almacen.readByte();
                }
                nuevo.setGenero(dato);
                this.jTextField5.setText(nuevo.getGenero());
                dato="";
                
                /*Ruta*/
                almacen.seek(posicion);
                puntero=almacen.readInt();
                posicion+=4;
                almacen.seek(puntero);
                lon=almacen.readByte();
                for(int i=0; i<lon; i++){
                    dato=dato+(char)almacen.readByte();
                }
                nuevo.setDireccion(dato);
                dato="";
                
                /*Duracion*/
                almacen.seek(posicion);
                nuevo.setDuracion(almacen.readShort());
                posicion+=2;
                
                /*Enlace Artista*/
                almacen.seek(posicion);
                puntero=almacen.readInt();
                posicion+=4;
                almacen.seek(puntero);
                lon=almacen.readByte();
                for(int i=0; i<lon; i++){
                    dato=dato+(char)almacen.readByte();
                }
                nuevo.setEnlaceArtista(dato);
                this.jTextField6.setText(nuevo.getEnlaceArtista());
                dato="";
                
                /*Enlace Disquera*/
                almacen.seek(posicion);
                puntero=almacen.readInt();
                posicion+=4;
                almacen.seek(puntero);
                lon=almacen.readByte();
                for(int i=0; i<lon; i++){
                    dato=dato+(char)almacen.readByte();
                }
                nuevo.setEnlaceDisquera(dato);
                this.jTextField7.setText(nuevo.getEnlaceDisquera());
                dato="";
                
                /*Enlace Otros*/
                almacen.seek(posicion);
                puntero=almacen.readInt();
                posicion+=4;
                almacen.seek(puntero);
                lon=almacen.readByte();
                for(int i=0; i<lon; i++){
                    dato=dato+(char)almacen.readByte();
                }
                nuevo.setEnlaceOtros(dato);
                this.jTextField8.setText(nuevo.getEnlaceOtros());
                dato="";
                
                /*Info*/
                int leer;
                almacen.seek(posicion);
                puntero=almacen.readInt();
                posicion+=4;
                informacion.seek(puntero);
                leer=informacion.readInt();
                for(int i=0; i<leer; i++){
                    dato=dato+(char)informacion.readByte();
                }
                nuevo.setInfo(dato);
                dato="";
                
                /*Letra*/
                almacen.seek(posicion);
                puntero=almacen.readInt();
                posicion+=4;
                letra.seek(puntero);
                leer=letra.readInt();
                for(int i=0; i<leer; i++){
                    dato=dato+(char)letra.readByte();
                }
                nuevo.setLetra(dato);
                dato="";
        } catch (FileNotFoundException ex) {
            Logger.getLogger(Mostrar.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(Mostrar.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jTextField1 = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        jButton3 = new javax.swing.JButton();
        jTextField2 = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        jTextField3 = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jTextField4 = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        jTextField5 = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        jTextField6 = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        jTextField7 = new javax.swing.JTextField();
        jLabel8 = new javax.swing.JLabel();
        jTextField8 = new javax.swing.JTextField();
        jLabel9 = new javax.swing.JLabel();
        jTextField9 = new javax.swing.JTextField();
        jButton1 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setText("Disquera");

        jButton3.setText("Actualizar");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });

        jTextField2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField2ActionPerformed(evt);
            }
        });

        jLabel2.setText("Artista");

        jTextField3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField3ActionPerformed(evt);
            }
        });

        jLabel3.setText("Álbum  ");

        jLabel4.setText("Año     ");

        jTextField4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField4ActionPerformed(evt);
            }
        });

        jLabel5.setText("Genero");

        jTextField5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField5ActionPerformed(evt);
            }
        });

        jLabel6.setText("Enlace artista");

        jTextField6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField6ActionPerformed(evt);
            }
        });

        jLabel7.setText("Enlace disquera");

        jTextField7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField7ActionPerformed(evt);
            }
        });

        jLabel8.setText("Enlace otros");

        jTextField8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField8ActionPerformed(evt);
            }
        });

        jLabel9.setText("Letra");

        jTextField9.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField9ActionPerformed(evt);
            }
        });

        jButton1.setText("Agregar Archivo de Letra");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addGroup(layout.createSequentialGroup()
                            .addComponent(jLabel1)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, 257, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(layout.createSequentialGroup()
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(jLabel6)
                                .addComponent(jLabel5)
                                .addComponent(jLabel4))
                            .addGap(18, 18, 18)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(jTextField4, javax.swing.GroupLayout.PREFERRED_SIZE, 257, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jTextField5, javax.swing.GroupLayout.PREFERRED_SIZE, 257, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jTextField6, javax.swing.GroupLayout.PREFERRED_SIZE, 257, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGroup(layout.createSequentialGroup()
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(jLabel3)
                                .addComponent(jLabel2))
                            .addGap(48, 48, 48)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                .addComponent(jTextField3, javax.swing.GroupLayout.PREFERRED_SIZE, 257, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jTextField2, javax.swing.GroupLayout.PREFERRED_SIZE, 257, javax.swing.GroupLayout.PREFERRED_SIZE))))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                                .addComponent(jLabel7)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jTextField7, javax.swing.GroupLayout.PREFERRED_SIZE, 257, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel8)
                                    .addComponent(jLabel9))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jTextField9, javax.swing.GroupLayout.PREFERRED_SIZE, 257, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jTextField8, javax.swing.GroupLayout.PREFERRED_SIZE, 257, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addComponent(jButton1))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jButton3)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(jTextField2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel3)
                    .addComponent(jTextField3, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel4)
                    .addComponent(jTextField4, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5)
                    .addComponent(jTextField5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel6)
                    .addComponent(jTextField6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel7)
                    .addComponent(jTextField7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel8)
                    .addComponent(jTextField8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jTextField9, javax.swing.GroupLayout.PREFERRED_SIZE, 68, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jButton3)
                            .addComponent(jButton1)))
                    .addComponent(jLabel9))
                .addContainerGap(12, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        // TODO add your handling code here:
        //si realizo alguna modificacion a los datos se registra en una cancion actualizada
        Cancion actual = new Cancion();
        actual.setDisquera(this.jTextField1.getText());
        actual.setArtista(this.jTextField2.getText());
        actual.setAlbum(this.jTextField3.getText());
        actual.setAnio(Short.valueOf(this.jTextField4.getText()));
        actual.setGenero(this.jTextField5.getText());
        actual.setEnlaceArtista(this.jTextField6.getText());
        actual.setEnlaceDisquera(this.jTextField7.getText());
        actual.setEnlaceOtros(this.jTextField8.getText());
     try {
         RandomAccessFile almacen = new RandomAccessFile("Almacen.data","rw");
          RandomAccessFile indice = new RandomAccessFile("Indice.data","rw");
          RandomAccessFile siguientes = new RandomAccessFile("siguientes.data","rw");
         //actualizar disquera
         int posicion = n;
             int puntero;
             byte lon;
             int unidad1 = 397038;
             //
              /*Pista*/
            almacen.seek(posicion);
            puntero=almacen.readShort();
            posicion+=2;
            indice.seek(puntero);
                lon=indice.readByte();
                
                /*Disquera*/
                almacen.seek(posicion);
                puntero=almacen.readInt();
                posicion+=4;
                almacen.seek(puntero);
                lon=almacen.readByte();
         if(nuevo.getDisquera() != actual.getDisquera()){
             byte lonActual = (byte)actual.getDisquera().length();
                almacen.seek(puntero);
                almacen.writeByte(lonActual);//modifica el tamaño de disquera
                if(lon != lonActual){
                int aux2 = (int) lon;
                int punteroAux = puntero + 1 + aux2;
                long fin = almacen.length();
                almacen.seek(punteroAux);
                for(long i=punteroAux; i< fin; i++){
                    siguientes.writeByte(almacen.readByte());
                }
                int escribir = puntero +1;
                almacen.seek(escribir);
                almacen.writeBytes(actual.getDisquera());//editar la disquera
                for(int i=punteroAux; i<fin; i++){
                    almacen.writeByte(siguientes.readByte());//regresar los registros siguientes
                }
                //Mover punteros
                almacen.seek(n+2+4+2);
                int punteroAlbumA = almacen.readInt();
                almacen.seek(n +2+4+2+4+2);
                int punteroGeneroA = almacen.readInt();
                almacen.seek(n+2+4+2+4+2+4);
                int punteroRutaA = almacen.readInt();
                almacen.seek(n+2+4+2+4+2+4+4+2);
                int punteroEnlaceArtistaA = almacen.readInt();
                almacen.seek(n+2+4+2+4+2+4+4+2+4);
                int punteroEnlaceDisqueraA = almacen.readInt();
                almacen.seek(n+2+4+2+4+2+4+4+2+4+4);
                int punteroEnlaceOtrosA = almacen.readInt();
                if(lonActual > lon){//sumarle a los punteros
                    byte cambio = (byte) (lonActual - lon);
                    //album
                    punteroAlbumA+= cambio;
                    almacen.seek(n+2+4+2);
                    almacen.writeInt(punteroAlbumA);
                    //genero
                    punteroGeneroA+= cambio;
                    almacen.seek(n+2+4+2+4+2);
                    almacen.writeInt(punteroGeneroA);
                    //ruta
                    punteroRutaA+= cambio;
                    almacen.seek(n+2+4+2+4+2+4);
                    almacen.writeInt(punteroRutaA);
                    //enlace artista
                    punteroEnlaceArtistaA+= cambio;
                    almacen.seek(n+2+4+2+4+2+4+4+2);
                    almacen.writeInt(punteroEnlaceArtistaA);
                    //enlace disquera
                    punteroEnlaceDisqueraA+= cambio;
                    almacen.seek(n+2+4+2+4+2+4+4+2+4);
                    almacen.writeInt(punteroEnlaceDisqueraA);
                    //enlace otros
                    punteroEnlaceOtrosA+= cambio;
                    almacen.seek(n+2+4+2+4+2+4+4+2+4+4);
                    almacen.writeInt(punteroEnlaceOtrosA);
                }else{//restarle a los punteros
                    byte cambio = (byte) (lon - lonActual);
                     //album
                    punteroAlbumA-= cambio;
                    almacen.seek(n+2+4+2);
                    almacen.writeInt(punteroAlbumA);
                    //genero
                    punteroGeneroA-= cambio;
                    almacen.seek(n+2+4+2+4+2);
                    almacen.writeInt(punteroGeneroA);
                    //ruta
                    punteroRutaA-= cambio;
                    almacen.seek(n+2+4+2+4+2+4);
                    almacen.writeInt(punteroRutaA);
                    //enlace artista
                    punteroEnlaceArtistaA-= cambio;
                    almacen.seek(n+2+4+2+4+2+4+4+2);
                    almacen.writeInt(punteroEnlaceArtistaA);
                    //enlace disquera
                    punteroEnlaceDisqueraA-= cambio;
                    almacen.seek(n+2+4+2+4+2+4+4+2+4);
                    almacen.writeInt(punteroEnlaceDisqueraA);
                    //enlace otros
                    punteroEnlaceOtrosA-= cambio;
                    almacen.seek(n+2+4+2+4+2+4+4+2+4+4);
                    almacen.writeInt(punteroEnlaceOtrosA);
                }
                }else{
                    int escribir = puntero +1;
                almacen.seek(escribir);
                    almacen.writeBytes(actual.getDisquera());
                }
         }
         /*Artista*/
                almacen.seek(posicion);
                puntero=almacen.readShort();
                posicion+=2;
                indice.seek(puntero);
                lon=indice.readByte();
                if(nuevo.getArtista() != actual.getArtista()){
                for(int i=0; i<lon; i++){
                    indice.writeBytes(actual.getArtista());
                }
                }
         /*Album*/
                almacen.seek(posicion);
                puntero=almacen.readInt();
                posicion+=4;
                almacen.seek(puntero);
                lon=almacen.readByte();
                if(nuevo.getAlbum() != actual.getAlbum()){
                for(int i=0; i<lon; i++){
                    almacen.writeBytes(actual.getAlbum());
                }
                }
            /*Año*/
                almacen.seek(posicion);
                puntero=almacen.readShort();
                posicion+=2;
                indice.seek(puntero);
                if(nuevo.getAnio() != actual.getAnio()){
                    indice.writeShort(actual.getAnio());
                }
            /*Genero*/
                almacen.seek(posicion);
                puntero=almacen.readInt();
                posicion+=4;
                almacen.seek(puntero);
                lon=almacen.readByte();
                if(nuevo.getGenero() != actual.getGenero()){
                for(int i=0; i<lon; i++){
                    almacen.writeBytes(actual.getGenero());
                }
                }
                
                /*Ruta*/
                almacen.seek(posicion);
                puntero=almacen.readInt();
                posicion+=4;
                almacen.seek(puntero);
                lon=almacen.readByte();
                
                /*Duracion*/
                almacen.seek(posicion);
                posicion+=2;
                
                /*Enlace Artista*/
                almacen.seek(posicion);
                puntero=almacen.readInt();
                posicion+=4;
                almacen.seek(puntero);
                lon=almacen.readByte();
                if(nuevo.getEnlaceArtista() != actual.getEnlaceArtista()){
                for(int i=0; i<lon; i++){
                    almacen.writeBytes(actual.getEnlaceArtista());
                }
                }
                
                /*Enlace Disquera*/
                almacen.seek(posicion);
                puntero=almacen.readInt();
                posicion+=4;
                almacen.seek(puntero);
                lon=almacen.readByte();
                if(nuevo.getEnlaceDisquera() != actual.getEnlaceDisquera()){
                for(int i=0; i<lon; i++){
                    almacen.writeBytes(actual.getEnlaceDisquera());
                }
                }
                /*Enlace Otros*/
                almacen.seek(posicion);
                puntero=almacen.readInt();
                posicion+=4;
                almacen.seek(puntero);
                lon=almacen.readByte();
                if(nuevo.getEnlaceOtros() != actual.getEnlaceOtros()){
                for(int i=0; i<lon; i++){
                    almacen.writeBytes(actual.getEnlaceOtros());
                }
                }
                
         //almacen1.writeByte(nuevo.getDisquera());
     } catch (FileNotFoundException ex) {
         Logger.getLogger(Edicion.class.getName()).log(Level.SEVERE, null, ex);
     } catch (IOException ex) {
         Logger.getLogger(Edicion.class.getName()).log(Level.SEVERE, null, ex);
     }
    }//GEN-LAST:event_jButton3ActionPerformed

    private void jTextField2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField2ActionPerformed

    private void jTextField3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField3ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField3ActionPerformed

    private void jTextField4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField4ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField4ActionPerformed

    private void jTextField5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField5ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField5ActionPerformed

    private void jTextField6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField6ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField6ActionPerformed

    private void jTextField7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField7ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField7ActionPerformed

    private void jTextField8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField8ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField8ActionPerformed

    private void jTextField9ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField9ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField9ActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
        LetraA letra = new LetraA();
        letra.setVisible(true);
    }//GEN-LAST:event_jButton1ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Edicion.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Edicion.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Edicion.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Edicion.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton3;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JTextField jTextField2;
    private javax.swing.JTextField jTextField3;
    private javax.swing.JTextField jTextField4;
    private javax.swing.JTextField jTextField5;
    private javax.swing.JTextField jTextField6;
    private javax.swing.JTextField jTextField7;
    private javax.swing.JTextField jTextField8;
    private javax.swing.JTextField jTextField9;
    // End of variables declaration//GEN-END:variables
}
